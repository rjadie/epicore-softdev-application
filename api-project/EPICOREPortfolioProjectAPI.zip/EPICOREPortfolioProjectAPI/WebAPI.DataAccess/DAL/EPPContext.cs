namespace WebAPI.DataAccess.DAL
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using WebAPI.Model.Models;

    public partial class EPPContext : DbContext
    {
        public EPPContext()
            : base("name=EPPContext")
        {
        }

        public virtual DbSet<AssessmentInterval> AssessmentIntervals { get; set; }
        public virtual DbSet<AssessmentMedication> AssessmentMedications { get; set; }
        public virtual DbSet<CVDRiskEngineType> CVDRiskEngineTypes { get; set; }
        public virtual DbSet<CVDRiskFactorMetric> CVDRiskFactorMetrics { get; set; }
        public virtual DbSet<CVDRiskFactorType> CVDRiskFactorTypes { get; set; }
        public virtual DbSet<EthnicityType> EthnicityTypes { get; set; }
        public virtual DbSet<MedicationCategory> MedicationCategories { get; set; }
        public virtual DbSet<Patient> Patients { get; set; }
        public virtual DbSet<PatientAssessment> PatientAssessments { get; set; }
        public virtual DbSet<PatientCVDRiskFactor> PatientCVDRiskFactors { get; set; }
        public virtual DbSet<PatientIdentification> PatientIdentifications { get; set; }
        public virtual DbSet<PatientIdentificationType> PatientIdentificationTypes { get; set; }
        public virtual DbSet<PatientStatu> PatientStatus { get; set; }
        public virtual DbSet<PatientStatusType> PatientStatusTypes { get; set; }
        public virtual DbSet<Pharmacist> Pharmacists { get; set; }
        public virtual DbSet<TreatmentSite> TreatmentSites { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AssessmentInterval>()
                .Property(e => e.IntervalName)
                .IsUnicode(false);

            modelBuilder.Entity<AssessmentMedication>()
                .Property(e => e.MedicationName)
                .IsUnicode(false);

            modelBuilder.Entity<AssessmentMedication>()
                .Property(e => e.MedicationDosage)
                .IsUnicode(false);

            modelBuilder.Entity<CVDRiskEngineType>()
                .Property(e => e.EngineName)
                .IsUnicode(false);

            modelBuilder.Entity<CVDRiskEngineType>()
                .Property(e => e.EngineDescription)
                .IsUnicode(false);

            modelBuilder.Entity<CVDRiskFactorMetric>()
                .Property(e => e.RiskFactorDescription)
                .IsUnicode(false);

            modelBuilder.Entity<CVDRiskFactorType>()
                .Property(e => e.RiskFactorTypeDescription)
                .IsUnicode(false);

            modelBuilder.Entity<EthnicityType>()
                .Property(e => e.EthnicityTypeDescription)
                .IsUnicode(false);

            modelBuilder.Entity<MedicationCategory>()
                .Property(e => e.CategoryName)
                .IsUnicode(false);

            modelBuilder.Entity<Patient>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Patient>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<Patient>()
                .Property(e => e.Gender)
                .IsUnicode(false);

            modelBuilder.Entity<PatientCVDRiskFactor>()
                .Property(e => e.AdditionalDetails)
                .IsUnicode(false);

            modelBuilder.Entity<PatientIdentification>()
                .Property(e => e.IdentificationNotes)
                .IsUnicode(false);

            modelBuilder.Entity<PatientIdentificationType>()
                .Property(e => e.PatientIdentificationType1)
                .IsUnicode(false);

            modelBuilder.Entity<PatientStatu>()
                .Property(e => e.StatusNotes)
                .IsUnicode(false);

            modelBuilder.Entity<PatientStatusType>()
                .Property(e => e.StatusTypeDescription)
                .IsUnicode(false);

            modelBuilder.Entity<Pharmacist>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Pharmacist>()
                .Property(e => e.LastName)
                .IsUnicode(false);

            modelBuilder.Entity<TreatmentSite>()
                .Property(e => e.SiteName)
                .IsUnicode(false);

            modelBuilder.Entity<TreatmentSite>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<TreatmentSite>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<TreatmentSite>()
                .Property(e => e.PostalCode)
                .IsFixedLength()
                .IsUnicode(false);
        }
    }
}
