﻿using PlayMeeting.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Model.Models;
using WebAPI.Model.ViewModels;

namespace WebAPI.DataAccess.Handlers
{
    public class PatientsHandler
    {
        public PatientsHandler()
        {

        }

        #region Create Methods

        public APIResponse<CreatePatientParamsVM> GetPatientParams()
        {
            APIResponse<CreatePatientParamsVM> response = new APIResponse<CreatePatientParamsVM>();
            try
            {
                DBTasks tasks = new DBTasks();
                response = tasks.GetPatientParams();
            }
            catch (Exception ex)
            {
                response.Messages.Add(new Message()
                {
                    MessageCode = "GPP001",
                    MessageSeverity = MessageSeverity.Error,
                    MessageText = ex.InnerException.Message
                });
            }

            return response;
        }

        public async Task<APIResponse<PostResponseVM>> AddPatient(Patient newPatient)
        {
            APIResponse<PostResponseVM> response = new APIResponse<PostResponseVM>();
            try
            {
                DBTasks tasks = new DBTasks();
                response = await tasks.AddPatient(newPatient);
            }
            catch (Exception ex)
            {
                response.Messages.Add(new Message()
                {
                    MessageCode = "AP001",
                    MessageSeverity = MessageSeverity.Error,
                    MessageText = ex.InnerException.Message
                });
            }

            return response;
        }

        #endregion

        #region Read Method

        public APIResponse<List<PatientVM>> GetPatients()
        {
            APIResponse<List<PatientVM>> response = new APIResponse<List<PatientVM>>();
            try
            {
                DBTasks tasks = new DBTasks();
                response = tasks.GetPatients();
            }
            catch (Exception ex)
            {
                response.Messages.Add(new Message()
                {
                    MessageCode = "GP001",
                    MessageSeverity = MessageSeverity.Error,
                    MessageText = ex.InnerException.Message
                });
            }

            return response;
        }

        #endregion

    }
}
