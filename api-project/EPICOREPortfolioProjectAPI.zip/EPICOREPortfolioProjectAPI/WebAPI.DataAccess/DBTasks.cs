﻿using PlayMeeting.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPI.DataAccess.DAL;
using WebAPI.Model.Models;
using WebAPI.Model.ViewModels;

namespace WebAPI.DataAccess
{
    public class DBTasks
    {
        #region Create Methods

        public APIResponse<CreatePatientParamsVM> GetPatientParams()
        {
            APIResponse<CreatePatientParamsVM> response = new APIResponse<CreatePatientParamsVM>();

            using (var context = new EPPContext())
            {
                var pharmacists = (from pharm in context.Pharmacists
                                   select new PharmacistVM
                                   {
                                    PharmacistID = pharm.PharmacistID,
                                    FullName = pharm.LastName + ", " + pharm.LastName
                                   }).ToList();

                var ethnicities = (from ethn in context.EthnicityTypes
                                  select new EthnicityVM
                                  {
                                    EthnicityID = ethn.EthnicityTypeID,
                                    Ethnicity = ethn.EthnicityTypeDescription
                                  }).ToList();

                if (pharmacists == null || pharmacists.Count() == 0)
                {
                    response.Messages.Add(new Message()
                    {
                        MessageCode = "GPP001",
                        MessageSeverity = MessageSeverity.Warning,
                        MessageText = "Sorry, there are no pharmacists to display."
                    });
                }

                if (ethnicities == null || ethnicities.Count() == 0)
                {
                    response.Messages.Add(new Message()
                    {
                        MessageCode = "GPP002",
                        MessageSeverity = MessageSeverity.Warning,
                        MessageText = "Sorry, there are no ethnicities to display."
                    });
                }

                if (response.Messages.Count() == 0)
                {
                    CreatePatientParamsVM patientParams = new CreatePatientParamsVM();
                    patientParams.Pharmacists = pharmacists;
                    patientParams.Ethnicities = ethnicities;
                    response.Response = patientParams;
                }
            }

            return response;
        }

        public async Task<APIResponse<PostResponseVM>> AddPatient(Patient newPatient)
        {
            APIResponse<PostResponseVM> response = new APIResponse<PostResponseVM>();

            using (var context = new EPPContext())
            {
                Patient patientToAdd = new Patient();

                var validPharmIds = (from pharms in context.Pharmacists
                                     select pharms.PharmacistID).ToList();

                if (!validPharmIds.Contains(newPatient.PharmacistID))
                {
                    response.Messages.Add(new Message()
                    {
                        MessageCode = "AP001",
                        MessageSeverity = MessageSeverity.Error,
                        MessageText = "Please submit a valid pharmacist id to add a patient."
                    });
                }
                else
                {
                    patientToAdd.PharmacistID = newPatient.PharmacistID;
                }

                var validEthnicityIds = (from ethns in context.EthnicityTypes
                                         select ethns.EthnicityTypeID).ToList();

                if (!validEthnicityIds.Contains(newPatient.EthnicityTypeID))
                {
                    response.Messages.Add(new Message()
                    {
                        MessageCode = "AP002",
                        MessageSeverity = MessageSeverity.Error,
                        MessageText = "Please submit a valid ethnicity id to add a patient."
                    });
                }
                else
                {
                    patientToAdd.EthnicityTypeID = newPatient.EthnicityTypeID;
                }

                if (response.Messages.Count() == 0)
                {
                    patientToAdd.FirstName = newPatient.FirstName;
                    patientToAdd.LastName = newPatient.LastName;
                    patientToAdd.Age = newPatient.Age;
                    patientToAdd.Gender = newPatient.Gender;
                    patientToAdd.PhysicianIsInformed = newPatient.PhysicianIsInformed;

                    context.Patients.Add(newPatient);
                    await context.SaveChangesAsync();

                    PostResponseVM responseObj = new PostResponseVM
                    {
                        NewRecordId = newPatient.PatientID,
                        ResponseMessage = "Patient added successfully."
                    };

                    response.Response = responseObj;
                }
                
            }

            return response;
        }

        #endregion

        #region Read Method

        public APIResponse<List<PatientVM>> GetPatients()
        {
            APIResponse<List<PatientVM>> response = new APIResponse<List<PatientVM>>();

            using (var context = new EPPContext())
            {
                var patients = (from patient in context.Patients
                               select new PatientVM
                               {
                                   FirstName = patient.FirstName,
                                   LastName = patient.LastName,
                                   Age = patient.Age,
                                   Gender = patient.Gender,
                                   PhysicianIsInformed = patient.PhysicianIsInformed,
                                   Ethnicity = (from ethnicity in context.EthnicityTypes
                                                where ethnicity.EthnicityTypeID == patient.EthnicityTypeID
                                                select ethnicity.EthnicityTypeDescription).FirstOrDefault(),
                                   Pharmacist = (from pharmacist in context.Pharmacists
                                                 where pharmacist.PharmacistID == patient.PharmacistID
                                                 select pharmacist.LastName + ", " + pharmacist.FirstName).FirstOrDefault()
                               }).ToList();

                if (patients == null || patients.Count() == 0)
                {
                    response.Messages.Add(new Message()
                    {
                        MessageCode = "GP001",
                        MessageSeverity = MessageSeverity.Warning,
                        MessageText = "Sorry, there are no patients to display."
                    });
                }
                else
                {
                    response.Response = patients;
                }
            }

            return response;
        }

        #endregion

    }
}
