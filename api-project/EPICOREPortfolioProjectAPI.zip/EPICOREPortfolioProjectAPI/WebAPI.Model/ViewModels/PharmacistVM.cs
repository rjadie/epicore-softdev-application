﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Model.ViewModels
{
    public class PharmacistVM
    {
        public int PharmacistID { get; set; }

        public string FullName { get; set; }
    }
}
