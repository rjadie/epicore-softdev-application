﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Model.ViewModels
{
    public class CreatePatientParamsVM
    {
        public List<PharmacistVM> Pharmacists { get; set; }

        public List<EthnicityVM> Ethnicities { get; set; }
    }
}
