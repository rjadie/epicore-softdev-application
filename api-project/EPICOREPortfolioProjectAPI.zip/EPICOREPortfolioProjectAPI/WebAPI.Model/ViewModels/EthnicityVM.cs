﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Model.ViewModels
{
    public class EthnicityVM
    {
        public int EthnicityID { get; set; }

        public string Ethnicity { get; set; }
    }
}
