﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Model.ViewModels
{
    public class PatientVM
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int? Age { get; set; }

        public string Gender { get; set; }

        public bool? PhysicianIsInformed { get; set; }

        public string Ethnicity { get; set; }

        public string Pharmacist { get; set; }
    }
}
