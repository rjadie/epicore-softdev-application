﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Model.ViewModels
{
    public class PostResponseVM
    {
        public int NewRecordId { get; set; }
        public string ResponseMessage { get; set; }
    }
}
