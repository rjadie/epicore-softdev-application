﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PlayMeeting.Model
{
    public class APIResponse<T>
    {
        public List<Message> Messages { get; set; }
        public string ApiVersionNumber { get; set; }
        public T Response { get; set; }

        public bool IsSuccess => !Messages.Any(m => m.MessageSeverity == MessageSeverity.Error);

        public APIResponse()
        {
            Messages = new List<Message>();
            ApiVersionNumber = Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }
    }

    public class Message
    {
        // Message Code is usually the initial of the file or command then followed by 3 digits
        // i.e Get Patients is GP so the message code will be GP001, GP002, etc.
        public string MessageCode { get; set; }
        public string MessageText { get; set; }
        public string MessageSeverity { get; set; }
    }

    public static class MessageSeverity
    {
        public static string Error = "Error";
        public static string Warning = "Warning";
        public static string Information = "Information";
        public static string Verbose = "Verbose";
        public static string Fatal = "Fatal";
    }
}
