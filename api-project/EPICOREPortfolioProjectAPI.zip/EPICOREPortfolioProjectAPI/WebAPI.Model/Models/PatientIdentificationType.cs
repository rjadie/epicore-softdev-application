namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PatientIdentificationType")]
    public partial class PatientIdentificationType
    {
        public int PatientIdentificationTypeID { get; set; }

        [Column("PatientIdentificationType")]
        [StringLength(75)]
        public string PatientIdentificationType1 { get; set; }
    }
}
