namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TreatmentSite")]
    public partial class TreatmentSite
    {
        public int TreatmentSiteID { get; set; }

        [StringLength(25)]
        public string SiteName { get; set; }

        [StringLength(25)]
        public string Address { get; set; }

        [StringLength(25)]
        public string City { get; set; }

        [StringLength(6)]
        public string PostalCode { get; set; }
    }
}
