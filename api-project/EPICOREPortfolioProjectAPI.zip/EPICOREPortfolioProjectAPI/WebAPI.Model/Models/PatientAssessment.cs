namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PatientAssessment")]
    public partial class PatientAssessment
    {
        public int PatientAssessmentID { get; set; }

        public int? PatientID { get; set; }

        public int? AssessmentIntervalID { get; set; }

        public int? CVDRiskEngineTypeID { get; set; }

        public decimal? CVDRiskPercent { get; set; }

        public bool? IsCarriedForward { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AssessmentDateTime { get; set; }

        public int? SystolicBloodPressure { get; set; }

        public int? DiastolicBloodPressure { get; set; }

        public int? WaistCircumference { get; set; }

        public decimal? Weight { get; set; }

        public decimal? Height { get; set; }

        public decimal? HbA1C { get; set; }

        public bool? IsCurrentSmoker { get; set; }

        public bool? HasSedentaryLifestyle { get; set; }

        public decimal? LDLC { get; set; }

        public decimal? HDL { get; set; }

        public decimal? Triglycerides { get; set; }

        public decimal? TotalCholesterol { get; set; }

        public decimal? EstimatedGlomerularFiltrationRate { get; set; }

        public decimal? AlbuminToCreatinineRatio { get; set; }
    }
}
