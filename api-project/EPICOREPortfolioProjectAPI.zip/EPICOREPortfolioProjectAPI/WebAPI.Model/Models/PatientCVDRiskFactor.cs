namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PatientCVDRiskFactor")]
    public partial class PatientCVDRiskFactor
    {
        public int PatientCVDRiskFactorID { get; set; }

        public int? PatientID { get; set; }

        public int? CVDRiskFactorMetricID { get; set; }

        [StringLength(50)]
        public string AdditionalDetails { get; set; }

        public int? YearsWithRiskFactor { get; set; }
    }
}
