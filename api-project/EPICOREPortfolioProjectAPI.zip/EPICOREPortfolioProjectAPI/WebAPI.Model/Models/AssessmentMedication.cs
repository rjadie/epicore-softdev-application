namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AssessmentMedication")]
    public partial class AssessmentMedication
    {
        public int AssessmentMedicationID { get; set; }

        public int? PatientAssessmentID { get; set; }

        public int? MedicationCategoryID { get; set; }

        [StringLength(25)]
        public string MedicationName { get; set; }

        [StringLength(25)]
        public string MedicationDosage { get; set; }
    }
}
