namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CVDRiskFactorMetric")]
    public partial class CVDRiskFactorMetric
    {
        public int CVDRiskFactorMetricID { get; set; }

        public int? CVDRiskFactorTypeID { get; set; }

        [StringLength(200)]
        public string RiskFactorDescription { get; set; }
    }
}
