namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CVDRiskEngineType")]
    public partial class CVDRiskEngineType
    {
        public int CVDRiskEngineTypeID { get; set; }

        [StringLength(100)]
        public string EngineName { get; set; }

        [StringLength(100)]
        public string EngineDescription { get; set; }
    }
}
