namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AssessmentInterval")]
    public partial class AssessmentInterval
    {
        public int AssessmentIntervalID { get; set; }

        [StringLength(10)]
        public string IntervalName { get; set; }
    }
}
