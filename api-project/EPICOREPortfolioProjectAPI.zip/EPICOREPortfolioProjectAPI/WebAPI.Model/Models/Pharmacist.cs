namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Pharmacist")]
    public partial class Pharmacist
    {
        public int PharmacistID { get; set; }

        public int? TreatmentSiteID { get; set; }

        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(25)]
        public string LastName { get; set; }
    }
}
