namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("MedicationCategory")]
    public partial class MedicationCategory
    {
        public int MedicationCategoryID { get; set; }

        [StringLength(25)]
        public string CategoryName { get; set; }
    }
}
