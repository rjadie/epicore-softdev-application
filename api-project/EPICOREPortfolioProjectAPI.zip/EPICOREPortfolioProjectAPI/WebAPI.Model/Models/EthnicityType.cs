namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("EthnicityType")]
    public partial class EthnicityType
    {
        public int EthnicityTypeID { get; set; }

        [StringLength(75)]
        public string EthnicityTypeDescription { get; set; }
    }
}
