namespace WebAPI.Model.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Patient")]
    public partial class Patient
    {
        public int PatientID { get; set; }

        public int PharmacistID { get; set; }

        public int EthnicityTypeID { get; set; }

        [StringLength(25)]
        public string FirstName { get; set; }

        [StringLength(25)]
        public string LastName { get; set; }

        public int Age { get; set; }

        [StringLength(10)]
        public string Gender { get; set; }

        public bool PhysicianIsInformed { get; set; }
    }
}
