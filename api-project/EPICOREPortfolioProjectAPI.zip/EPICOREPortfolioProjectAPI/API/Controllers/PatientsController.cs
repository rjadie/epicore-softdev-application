﻿using PlayMeeting.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebAPI.DataAccess.Handlers;
using WebAPI.Model.Models;
using WebAPI.Model.ViewModels;
using System.Threading.Tasks;

namespace API.Controllers
{
    [RoutePrefix("API")]
    public class PatientsController : ApiController
    {
        #region Create Methods

        [HttpGet]
        [Route("GetPatientParams/")]
        [ResponseType(typeof(APIResponse<CreatePatientParamsVM>))]
        public IHttpActionResult GetPatientParams()
        {
            APIResponse<CreatePatientParamsVM> response = new APIResponse<CreatePatientParamsVM>();

            PatientsHandler handler = new PatientsHandler();
            response = handler.GetPatientParams();

            return Ok(response);
        }

        [HttpPost]
        [Route("AddPatient/")]
        [ResponseType(typeof(APIResponse<PostResponseVM>))]
        public async Task<IHttpActionResult> AddPatient([FromBody] Patient newPatient)
        {
            APIResponse<PostResponseVM> response = new APIResponse<PostResponseVM>();

            PatientsHandler handler = new PatientsHandler();
            response = await handler.AddPatient(newPatient);

            return Ok(response);
        }

        #endregion

        #region Read Method

        [HttpGet]
        [Route("GetPatients/")]
        [ResponseType(typeof(APIResponse<List<PatientVM>>))]
        public IHttpActionResult GetPatients()
        {
            APIResponse<List<PatientVM>> response = new APIResponse<List<PatientVM>>();
            
            PatientsHandler handler = new PatientsHandler();
            response = handler.GetPatients();

            return Ok(response);
        }

        #endregion

    }
}
